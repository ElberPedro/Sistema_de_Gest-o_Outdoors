<?php
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/controller/AdminController.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/controller/OutdoorController.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/controller/LocalidadeController.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/model/Outdoor.php';
session_start();
?>
<html>
    <head>
        <title>XPTO-SOLUTIONS</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../content/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../content/estilo.css">
    </head>
    <body>

        <div class="logo">
        </div>
        <nav class="navbar  fixed-top navbar-expand-lg bg-azul">
            <a class="navbar-brand" href="GestorView.php."> INICIO | </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <ul class="navbar-nav mr-auto">
                    <ul class="navbar-nav mr-auto">

                        <li class="nav-item">
                            <a class="nav-link" href="#" data-target="#analisarAluguerModal">Analisar Aluguer</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#" data-target="#inserirOutdoorModal">Inserir Outdoor</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#" data-target="#gerirOutdoorModal">Gerir Outdoor</a>
                        </li>
                        <li class="nav-item ml-auto">
                            <a class="nav-link" href="../actions/logout.php">Sair</a>
                        </li>
                        </div>
                        </nav>
                        <div class="hero">
                            <div class="hero__title">GESTOR<br/><?php echo $_SESSION['manager']['nome']; ?></div>
                            <div class="cube"></div>
                            <div class="cube"></div>
                            <div class="cube"></div>
                            <div class="cube"></div>
                            <div class="cube"></div>
                            <div class="cube"></div>
                        </div>
                        <!-- Modal para a tela de inserir um Outdoor -->
                        <div class="modal" id="inserirOutdoorModal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <form method="POST" enctype="multipart/form-data">
                                            <table class='table table-bordered table-responsive'>
                                                <br/>
                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="estado" value="disponivel">

                                                        <select name="tipoOutdoor" class="form-control">
                                                            <option>Tipos de Outdoor</option>
                                                            <option value="Placas Luminosas">Placas Luminosas</option>
                                                            <option value="Placas Nao Luminosas">Placas Nao Luminosas</option>
                                                            <option value="Lampoles">Lampoles</option>
                                                            <option value="Placas Indicativas">Placas Indicativas</option>
                                                            <option value="Faixadas">Faixadas</option>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <select name="preco" class="form-control">
                                                            <option>Preco</option>
                                                            <option value="10.000,00">10.000,00</option>
                                                            <option value="20.000,00">20.000,00</option>
                                                            <option value="30.000,00">30.000,00</option>
                                                            <option value="40.000,00">40.000,00</option>
                                                            <option value="50.000,00">50.000,00</option>
                                                            <option value="60.000,00">60.000,00</option>
                                                            <option value="1.000.000,00">1.000.000,00</option>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <select name="provincia" id="provinciaSelect" class="form-control">
                                                            <option>Provincia</option>
                                                            <?php
                                                            $localidadeController->mostrarProvincia();
                                                            ?>
                                                        </select>  
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <select name="municipio" id="municipioSelect" class="form-control">
                                                            <option>Municipio</option>

                                                        </select>  
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <select name="comuna" id="comunaSelect" class="form-control">
                                                            <option>Comuna</option>
                                                        </select>  
                                                    </td>
                                                </tr> 
                                                <tr>
                                                    <td><input type="file" accept="image/*" name="imagem" class="form-control"></td>
                                                </tr>
                                            </table>
                                            <button type="submit" class="btn btn-dark" name="add_outdoor">Inserir</button>
                                        </form>
                                        <?php
                                        if (isset($_POST['add_outdoor'])) {
                                            $outdoor = new Outdoor();

                                            $tipoOutdoor = filter_input(INPUT_POST, 'tipoOutdoor', FILTER_SANITIZE_STRING);
                                            $preco = filter_input(INPUT_POST, 'preco', FILTER_SANITIZE_STRING);
                                            $estado = filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_EMAIL);
                                            $comuna = filter_input(INPUT_POST, 'comuna', FILTER_SANITIZE_STRING);
                                            $municipio = filter_input(INPUT_POST, 'municipio', FILTER_SANITIZE_STRING);
                                            $provincia = filter_input(INPUT_POST, 'provincia', FILTER_SANITIZE_STRING);

                                            $imagem = $_FILES['imagem'];

                                            if ($imagem['error'] === UPLOAD_ERR_OK) {
                                                // Obter o caminho temporário do arquivo
                                                $caminhoTemporario = $imagem['tmp_name'];

                                                // Ler o conteúdo do arquivo
                                                $conteudo = file_get_contents($caminhoTemporario);

                                                $outdoor->setTipoOutdoor($tipoOutdoor);
                                                $outdoor->setPreco($preco);
                                                $outdoor->setEstado($estado);
                                                $outdoor->setProvincia($provincia);
                                                $outdoor->setMunicipio($municipio);
                                                $outdoor->setComuna($comuna);

                                                $outdoor->setImagem($conteudo);

                                                $outdoorController->addOutdoor($outdoor);

                                                echo "<meta http-equiv=\"refresh\" content=\"0;\">";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal para a tela de adicionar um Gestor -->
                        <div class="modal" id="analisarAluguerModal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Nome Cliente</th>
                                                        <th scope="col">Tipo de Outdoor</th>
                                                        <th scope="col">PDF</th>
                                                        <th scope="col">Aprovar</th>
                                                        <th scope="col">Recusar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $total = 0;
                                                    foreach ($outdoorController->validarComprovativo() as $outdoor) {
                                                        echo "<tr>";
                                                        echo "<td>" . $outdoor->getClienteNome() . "</td>";
                                                        echo "<td>" . $outdoor->getTipoOutdoor() . "</td>";
                                                        echo "<td><a href='../actions/visualizar_pdf.php?outdoorId=" . $outdoor->getId() . "'>Visualizar PDF</a></td>";
                                                        echo "<form method='POST'>";
                                                        echo "<input type='hidden' value=" . $outdoor->getId() . " name='outdoorId'>";
                                                        echo '<td><input type="submit" name="aprovar_pedido" class="btn btn-success" value="Aprovar"></input></td>';
                                                        echo '<td><input type="submit" name="recusar_pedido" class="btn btn-danger" value="Recusar"></input></td>';
                                                        echo '</form>';
                                                        echo "</tr>";

                                                        $total += (int) $outdoor->getPreco();
                                                    }
                                                    echo '<th scope="row">Total a Pagar:</th>';
                                                    echo '<td colspan="4"><input type="hidden" name="precoTotal" value="' . $total . '"><span class="currency">Kz </span>' . $total . '<span class="currency">.000,00</span></td>';
                                                    ?>
                                                </tbody>
                                            </table>
                                            <?php
                                            if (isset($_POST['aprovar_pedido'])) {
                                                $outdoorId = filter_input(INPUT_POST, 'outdoorId', FILTER_SANITIZE_NUMBER_INT);
                                                $outdoorController->updateOutdoorEstado($outdoorId, 'Ocupado');
                                                $outdoorController->deleteAnalisarAluguer($outdoorId);
                                                echo "<meta http-equiv=\"refresh\" content=\"0;\">";
                                            }
                                            ?>

                                            <?php
                                            if (isset($_POST['recusar_pedido'])) {
                                                $outdoorId = filter_input(INPUT_POST, 'outdoorId', FILTER_SANITIZE_NUMBER_INT);
                                                $outdoorController->updateOutdoorEstado($outdoorId, 'Disponivel');
                                                $outdoorController->deleteAnalisarAluguer($outdoorId);
                                                echo "<meta http-equiv=\"refresh\" content=\"0;\">";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- Modal para a tela de adicionar um Gestor -->
                        <div class="modal" id="gerirOutdoorModal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header justify-content-center">
                                        <h5>Lista dos Outdoors</h5>
                                    </div>
                                    <div class="modal-body">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">id</th>
                                                        <th scope="col">Tipo de Outdoor</th>
                                                        <th scope="col">Preco</th>
                                                        <th scope="col">Estado</th>
                                                        <th scope="col">Provincia</th>
                                                        <th scope="col">Municipio</th>
                                                        <th scope="col">Comuna</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    foreach ($outdoorController->showOutdoor() as $outdoor):
                                                        echo "<tr>";
                                                        echo "<td>" . $outdoor->getId() . "</td>";
                                                        echo "<td>" . $outdoor->getTipoOutdoor() . "</td>";
                                                        echo "<td>" . $outdoor->getPreco() . "</td>";
                                                        echo "<td>" . $outdoor->getEstado() . "</td>";
                                                        echo "<td>" . $outdoor->getProvincia() . "</td>";
                                                        echo "<td>" . $outdoor->getMunicipio() . "</td>";
                                                        echo "<td>" . $outdoor->getComuna() . "</td>";
                                                        echo '<td><a href="#" data-bs-target="#editarUserModal" name="editar" class="btn btn-outline-primary">Editar</a></td>';
                                                        echo"<form method='POST'>";
                                                        echo "<input type='text' hidden value=" . $outdoor->getId() . " name='id_value' class='form-control'>";
                                                        echo '<td><input type="submit" name="outdoorId" class="btn btn-danger" value="Excluir"></input>';
                                                        echo'</form>';
                                                        echo "</tr>";
                                                    endforeach;
                                                    ?>
                                                </tbody>
                                            </table>
                                            <?php
                                            if (isset($_POST['outdoorId'])) {
                                                $outdoorController->apagarOutdoor($_POST['id_value']);
                                                echo "<meta http-equiv=\"refresh\" content=\"0;\">";
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal para a tela de validar um User -->
                        <div class="modal" id="EditarAutenticacao" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header justify-content-center">
                                        <h5>Editar Autenticação</h5><br/>
                                    </div>
                                    <div class="modal-header justify-content-center">
                                        <p>Uma vez que a sua conta foi criada pelo administrador, é obrigatório alterar a informação de autenticacao!!!</p>
                                    </div>
                                    <div class="modal-body">
                                        <div class="table-responsive">
                                            <form method="POST" action="GestorView.php">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <td><input type="email" name="email" class="form-control" placeholder="E-Mail" required></td>
                                                        </tr>
                                                        <tr>
                                                            <td><input type="password" name="password" class="form-control" placeholder="Senha" required></td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    </tbody>
                                                </table>
                                                <button type="submit" class="btn btn btn-dark" name="edt_autenticacao">Confirmar</button>
                                            </form>
                                            <?php
                                            if (isset($_POST["edt_autenticacao"])) {
                                                $pass = $_POST["password"];
                                                $email = $_POST["email"];
                                                $adminController->updateAutenticacao($_SESSION['manager']['id'], $email, $pass);
                                                $_SESSION['manager']['estado'] = 'OLD';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <script src="../scripts/jquery/jquery.min.js"></script>
                        <script src="../scripts/bootstrap/css/bootstrap.min.js"></script>
                        <script src="../scripts/custom/gestor.js"></script>

                        <script>
                            var EditarAutenticacao = new bootstrap.Modal(document.getElementById("EditarAutenticacao"));
                            if ('<?php echo $_SESSION['manager']['estado']; ?>' == 'NEW') {
                                EditarAutenticacao.show();
                            }
                        </script>
                        <script src="../scripts/custom/localidade.js"></script>
                        </body>
            </html>