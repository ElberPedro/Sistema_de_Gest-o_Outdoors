<?php
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/controller/AdminController.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/model/User.php';
session_start();
?>
<html>
    <head>
        <title>Xpto-Solutions</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../content/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../content/estilo.css">
    </head> 
    <body>
        <div class="container">
            <div class="container">
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <a class="navbar-brand logo" href="../view/UserView.php">XPTO Soluctions</a>

                        <div class="container">
                            <h1>Login</h1>
                            <form method="POST">
                                <div class="form-group">
                                    <label for="email">Email</label><br/>
                                    <input type="email" class="form-control" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email" required=""><br/>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label><br/>
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required><br/>
                                </div>
                                <button type="submit" name="login_button" class="btn btn-primary">Entrar</button>
                                <a href="../view/UserView.php" class="btn btn-dark">Visitante</a>
                            </form>
                            <p class="text-center mt-3">Ainda não tem uma conta? <a class="nav-link" href="#" data-target="#addClientModal">Regista-se</a></p>
                        </div>
                        <?php
                        if (isset($_POST['login_button'])) {
                            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                            $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
                            $adminController->entrar($email, $password);
                        }
                        ?>
                    </div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>
        <script src="../scripts/bootstrap/css/bootstrap.min.js"></script>
    </body>
</html>
