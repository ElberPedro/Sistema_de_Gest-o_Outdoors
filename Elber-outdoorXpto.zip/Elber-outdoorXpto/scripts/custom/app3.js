document.addEventListener("DOMContentLoaded", function () {
    var EditarAutenticacao = new bootstrap.Modal(document.getElementById("EditarAutenticacao"));
    
    document.querySelector("a[data-target='#EditarAutenticacao']").addEventListener("click", function () {
        EditarAutenticacao.show();
    });
});