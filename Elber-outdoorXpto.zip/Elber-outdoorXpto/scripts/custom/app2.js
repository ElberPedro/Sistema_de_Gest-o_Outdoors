document.addEventListener("DOMContentLoaded", function () {
    var EditarEmail = new bootstrap.Modal(document.getElementById("EditarEmail"));
    
    document.querySelector("a[data-target='#EditarEmail']").addEventListener("click", function () {
        EditarEmail.show();
    });
    
});



