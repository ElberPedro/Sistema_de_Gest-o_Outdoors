-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Jul-2023 às 08:49
-- Versão do servidor: 10.4.28-MariaDB
-- versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `elber_outdoorxpto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `alugar_outdoor`
--

CREATE TABLE `alugar_outdoor` (
  `outdoor_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `dataInicio` varchar(50) DEFAULT NULL,
  `dataFim` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `analisar_aluguer`
--

CREATE TABLE `analisar_aluguer` (
  `outdoor_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `dataInicio` varchar(50) DEFAULT NULL,
  `dataFim` varchar(50) DEFAULT NULL,
  `pdf` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `user_id` int(11) DEFAULT NULL,
  `nacionalidade` varchar(50) DEFAULT NULL,
  `tipoCliente` varchar(50) DEFAULT NULL,
  `atividadeEmpresa` varchar(50) DEFAULT NULL,
  `estado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`user_id`, `nacionalidade`, `tipoCliente`, `atividadeEmpresa`, `estado`) VALUES
(66, 'Angolano(a)', 'Particular', NULL, 'Aprovado'),
(78, 'angolano', 'Particular', NULL, 'Aprovado'),
(79, 'austríaco', 'Particular', NULL, 'Por Ativar');

-- --------------------------------------------------------

--
-- Estrutura da tabela `comuna`
--

CREATE TABLE `comuna` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `municipio_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `comuna`
--

INSERT INTO `comuna` (`id`, `nome`, `municipio_id`) VALUES
(1, 'Ambriz', 1),
(2, 'Bela Vista', 1),
(3, 'Tabi', 1),
(4, 'Bula Atumba', 2),
(5, 'Quiage', 2),
(6, 'caxito', 3),
(7, 'Barra do Dande', 3),
(8, 'Mabubas', 3),
(9, 'Quicabo', 3),
(10, 'Úcua', 3),
(11, 'Quibaxe', 4),
(12, 'Paredes', 4),
(13, 'Piri', 4),
(14, 'São José das Matas (antiga Quoxe)', 4),
(15, 'Muxaluando', 5),
(16, 'Cage', 5),
(17, 'Canacassala', 5),
(18, 'Gombe', 5),
(19, 'Quicunzo', 5),
(20, 'Quixico', 5),
(21, 'Zala', 5),
(22, 'Pango Aluquém', 6),
(23, 'Cazuangongo', 6),
(24, 'Baía Farta', 7),
(25, 'Dombe Grande', 7),
(26, 'Calahanga', 7),
(27, 'Equimina', 7),
(28, 'Balombo', 8),
(29, 'Chindumbo', 8),
(30, 'Chingongo', 8),
(31, 'Maca Mombolo', 8),
(32, 'Benguela', 9),
(33, 'Bocoio', 10),
(34, 'Chila', 10),
(35, 'Monte Belo', 10),
(36, 'Passe', 10),
(37, 'Cavimbe', 10),
(38, 'Cubal do Lumbo', 10),
(39, 'Caimbambo', 11),
(40, 'Catengue', 11),
(41, 'Caiave', 11),
(42, 'Canhamela', 11),
(43, 'Viangombe', 11),
(44, 'Catumbela', 12),
(45, 'Gama', 12),
(46, 'Biópio', 12),
(47, 'Praia Bebe', 12),
(48, 'Chongoroi', 13),
(49, 'Bolonguera', 13),
(50, 'Camuine', 13),
(51, 'Cubal', 14),
(52, 'Iambala', 14),
(53, 'Capupa', 14),
(54, 'Tumbulo (antiga Lomaum)', 14),
(55, 'Ganda', 15),
(56, 'Babaera', 15),
(57, 'Chicuma', 15),
(58, 'Ebanga', 15),
(59, 'Casseque', 15),
(60, 'Lobito', 16),
(61, 'Egipto Praia', 16),
(62, 'Canjala', 16),
(63, 'Andulo', 17),
(64, 'Calucinga', 17),
(65, 'Cassumbe', 17),
(66, 'Chivaúlo', 17),
(67, 'Camacupa', 18),
(68, 'Ringoma', 18),
(69, 'Santo António da Muinha', 18),
(70, 'Umpulo', 18),
(71, 'Cuanza', 18),
(72, 'Catabola', 19),
(73, 'Chipeta', 19),
(74, 'Caiuera', 19),
(75, 'Chiuca', 19),
(76, 'Sande', 19),
(77, 'Chinguar', 20),
(78, 'Cutato', 20),
(79, 'Cangote', 20),
(80, 'Chitembo', 21),
(81, 'Cachingues', 21),
(82, 'Mutumbo', 21),
(83, 'Mumbué', 21),
(84, 'Malengue', 21),
(85, 'Soma Cuanza', 21),
(86, 'Cuemba', 22),
(87, 'Luando', 22),
(88, 'Munhango', 22),
(89, 'Sachinemuna', 22),
(90, 'Cuíto', 23),
(91, 'Chicala', 23),
(92, 'Cambândua', 23),
(93, 'Cunje', 23),
(94, 'Trumba', 23),
(95, 'Cunhinga', 24),
(96, 'Belo Horizonte', 24),
(97, 'Nharea', 25),
(98, 'Gamba', 25),
(99, 'Lúbia', 25),
(100, 'Caiei', 25),
(101, 'Dando', 25),
(102, 'Belize', 26),
(103, 'Luali', 26),
(104, 'Miconje', 26),
(105, 'Buco-Zau', 27),
(106, 'Inhuca', 27),
(107, 'Necuto', 27),
(108, 'Cabinda', 28),
(109, 'Malembo', 28),
(110, 'Tanto-Zinze', 28),
(111, 'Cacongo', 29),
(112, 'Dinge', 29),
(113, 'Massabi', 29),
(114, 'Calai', 30),
(115, 'Maue', 30),
(116, 'Mavengue', 30),
(117, 'Cuangar', 31),
(118, 'Savate', 31),
(119, 'Caila (antiga Bondo)', 31),
(120, 'Cuchi', 32),
(121, 'Cutato', 32),
(122, 'Chinguanja', 32),
(123, 'Vissati', 32),
(124, 'Cuito Cuanavale', 33),
(125, 'Longa', 33),
(126, 'Lupire', 33),
(127, 'Baixo Longa', 33),
(128, 'Dirico', 34),
(129, 'Xamavera', 34),
(130, 'Mucusso', 34),
(131, 'Mavinga', 35),
(132, 'Cunjamba', 35),
(133, 'Cutuile', 35),
(134, 'Luengue', 35),
(135, 'Menongue', 36),
(136, 'Caiundo', 36),
(137, 'Cueio-Betre', 36),
(138, 'Missombo', 36),
(139, 'Nancova', 37),
(140, 'Rito', 37),
(141, 'Rivungo', 38),
(142, 'Luiana', 38),
(143, 'Chipundo', 38),
(144, 'Neriquinha', 38),
(145, 'Jamba-Cueio', 38),
(146, 'Camabatela', 39),
(147, 'Tango', 39),
(148, 'Maúa', 39),
(149, 'Bindo', 39),
(150, 'Luinga', 39),
(151, 'Banga', 40),
(152, 'Caculo Cabaça', 40),
(153, 'Cariamba', 40),
(154, 'Aldeia Nova', 40),
(155, 'Bolongongo', 41),
(156, 'Terreiro', 41),
(157, 'Quiquiemba', 41),
(158, 'Dondo', 42),
(159, 'Massangano', 42),
(160, 'Danje-ia-Menha', 42),
(161, 'Zenza do Itombe', 42),
(162, 'São Pedro da Quilemba', 42),
(163, 'Nadalatando', 43),
(164, 'Canhoca', 43),
(165, 'Golungo Alto', 44),
(166, 'Cambondo', 44),
(167, 'Cêrca', 44),
(168, 'Quiluanje', 44),
(169, 'Quilombo dos Dembos', 45),
(170, 'Camame', 45),
(171, 'Cavunga', 45),
(172, 'Lucala', 46),
(173, 'Quiangombe', 46),
(174, 'Quiculungo', 47),
(175, 'Samba Caju', 48),
(176, 'Samba Lucala', 48),
(177, 'Gabela', 49),
(178, 'Assango', 49),
(179, 'Cassongue', 50),
(180, 'Pambangala', 50),
(181, 'Dumbi', 50),
(182, 'Atome', 50),
(183, 'Uaco Cungo', 51),
(184, 'Quissanga', 51),
(185, 'Sanga', 51),
(186, 'Conda', 52),
(187, 'Cunjo', 52),
(188, 'Ebo', 53),
(189, 'Condé', 53),
(190, 'Quissanje', 53),
(191, 'Mussende', 54),
(192, 'São Lucas', 54),
(193, 'Quienha', 54),
(194, 'Porto Amboim', 55),
(195, 'Capolo', 55),
(196, 'Quibala', 56),
(197, 'Cariango', 56),
(198, 'Dala Cachibo', 56),
(199, 'Lonhe', 56),
(200, 'Quirimbo', 57),
(201, 'Quilenda', 57),
(202, 'Amboiva', 58),
(203, 'Botera', 58),
(204, 'Seles', 58),
(205, 'Sumbe', 59),
(206, 'Gangula', 59),
(207, 'Gungo', 59),
(208, 'Quicombo', 59),
(209, 'Cahama', 60),
(210, 'Oxinjau', 60),
(211, 'Ondijiva', 61),
(212, 'Môngua', 61),
(213, 'Evale', 61),
(214, 'Nehone Cafima', 61),
(215, 'Simporo', 61),
(216, 'Oncócua', 62),
(217, 'Chitado', 62),
(218, 'Mucolongodijo', 63),
(219, 'Mupa', 63),
(220, 'Calonga', 63),
(221, 'Cuvati', 63),
(222, 'Namacunde', 64),
(223, 'Chiede', 64),
(224, 'Xangongo', 65),
(225, 'Ombala yo Mungu', 65),
(226, 'Naulila', 65),
(227, 'Humbe', 65),
(228, 'Mucope', 65),
(229, 'Bailundo', 66),
(230, 'Lunge', 66),
(231, 'Luvemba', 66),
(232, 'Bimbe', 66),
(233, 'Hengue-Caculo', 66),
(234, 'Caála', 67),
(235, 'Cuíma', 67),
(236, 'Calenga', 67),
(237, 'Catata', 67),
(238, 'Cachiungo', 68),
(239, 'Chiumbo', 68),
(240, 'Chinhama', 68),
(241, 'Chicala-Choloanga', 69),
(242, 'Mbave', 69),
(243, 'Sambo', 69),
(244, 'Samboto (antiga Hungulo)', 69),
(245, 'Chinjenje', 70),
(246, 'Chiaca', 70),
(247, 'Ecunha', 71),
(248, 'Quipeio', 71),
(249, 'Huambo', 72),
(250, 'Chipipa', 72),
(251, 'Calima', 72),
(252, 'Londuimbali', 73),
(253, 'Angalanga', 73),
(254, 'Alto–Hama', 73),
(255, 'Ussoque', 73),
(256, 'Cumbira', 73),
(257, 'Longonjo ', 74),
(258, 'Lépi', 74),
(259, 'Iava', 74),
(260, 'Chilata', 74),
(261, 'Mungo', 75),
(262, 'Cambuengo', 75),
(263, 'Ucuma', 76),
(264, 'Cacoma', 76),
(265, 'Mundundo', 76),
(266, 'Caconda', 77),
(267, 'Gungue', 77),
(268, 'Uaba', 77),
(269, 'Cusse', 77),
(270, 'Caluquembe', 78),
(271, 'Calépi', 78),
(272, 'Ngola', 78),
(273, 'Chiange', 79),
(274, 'Chibemba', 79),
(275, 'Chibia', 80),
(276, 'Capunda-Cavilongo', 80),
(277, 'Quihita', 80),
(278, 'Jau', 80),
(279, 'Chicomba', 81),
(280, 'Cutenda', 81),
(281, 'Chipindo', 82),
(282, 'Bambi', 82),
(283, 'Cuvango', 83),
(284, 'Galangue', 83),
(285, 'Vicungo', 83),
(286, 'Humpata', 84),
(287, 'Jamba', 85),
(288, 'Cassinga', 85),
(289, 'Dongo', 85),
(290, 'Lubango', 86),
(291, 'Arimba', 86),
(292, 'Hoque', 86),
(293, 'Huíla', 86),
(294, 'Matala', 87),
(295, 'Capelongo', 87),
(296, 'Mulondo', 87),
(297, 'Quilengues', 88),
(298, 'Impulo', 88),
(299, 'Dinde', 88),
(300, 'Quipungo', 89),
(301, 'Belas', 90),
(302, 'Barra do Cuanza', 90),
(303, 'Cacuaco', 91),
(304, 'Funda', 91),
(305, 'Cazenga', 92),
(306, 'Ícolo e Bengo', 93),
(307, 'Bom Jesus do Cuanza', 93),
(308, 'Cabiri', 93),
(309, 'Cassoneca', 93),
(310, 'Caculo Cahango', 93),
(311, 'Luanda', 94),
(312, 'Quilamba Quiaxi', 95),
(313, 'Muxima', 96),
(314, 'Demba Chio', 96),
(315, 'Quixinge', 96),
(316, 'Mumbondo', 96),
(317, 'Caboledo', 96),
(318, 'Talatona', 97),
(319, 'Benfica', 97),
(320, 'Viana', 98),
(321, 'Calumbo', 98),
(322, 'Cambulo', 99),
(323, 'Luia', 99),
(324, 'Cachimo', 99),
(325, 'Canzar', 99),
(326, 'Capenda Camulemba', 100),
(327, 'Xinge', 100),
(328, 'Caungula', 101),
(329, 'Camaxilo', 101),
(330, 'Dundo-Chitato', 102),
(331, 'Luachimo', 102),
(332, 'Cuango', 103),
(333, 'Luremo', 103),
(334, 'Cuílo', 104),
(335, 'Caluango', 104),
(336, 'Lóvua', 105),
(337, 'Lubalo', 106),
(338, 'Luangue', 106),
(339, 'Muvuluege', 106),
(340, 'Lucapa', 107),
(341, 'Camissombo', 107),
(342, 'Capaia', 107),
(343, 'Xa–Cassau', 107),
(344, 'Xá-Muteba', 108),
(345, 'Iongo', 108),
(346, 'Cassanje Calucala', 108),
(347, 'Cacolo', 109),
(348, 'Alto Chicapa', 109),
(349, 'Xassengue', 109),
(350, 'Cucumbi', 109),
(351, 'Dala', 110),
(352, 'Cazage', 110),
(353, 'Luma Cassai', 110),
(354, 'Muconda', 111),
(355, 'Muriege', 111),
(356, 'Chiluage', 111),
(357, 'Cassai Sul', 111),
(358, 'Saurimo', 112),
(359, 'Mona Quimbundo', 112),
(360, 'Sombo', 112),
(361, 'Cacuso', 113),
(362, 'Lombe', 113),
(363, 'Quizenga', 113),
(364, 'Pungo-Andongo', 113),
(365, 'Soqueco', 113),
(366, 'Cambundi Catembo', 114),
(367, 'Quitapa', 114),
(368, 'Tala Mungongo', 114),
(369, 'Dumba Cambango', 114),
(370, 'Cangandala', 115),
(371, 'Bembo', 115),
(372, 'Culamagia', 115),
(373, 'Caribo', 115),
(374, 'Caombo', 116),
(375, 'Bange-Angola', 116),
(376, 'Cambo Suinginge', 116),
(377, 'Micanda', 116),
(378, 'Cuaba Nzoji', 117),
(379, 'Mufuma', 117),
(380, 'Cunda-Dia-Baze', 118),
(381, 'Lemba', 118),
(382, 'Milando', 118),
(383, 'Calandula', 119),
(384, 'Cateco Cangola', 119),
(385, 'Cota', 119),
(386, 'Cuale', 119),
(387, 'Quinje', 119),
(388, 'Luquembo', 120),
(389, 'Quimbango', 120),
(390, 'Capunda', 120),
(391, 'Dombo', 120),
(392, 'Cunga Palanga', 120),
(393, 'Rimba', 120),
(394, 'Malanje', 121),
(395, 'Nugola-Luije', 121),
(396, 'Cambaxe', 121),
(397, 'Marimba', 122),
(398, 'Cabombo', 122),
(399, 'Tembo-Aluma', 122),
(400, 'Massango', 123),
(401, 'Quihuhu', 123),
(402, 'Quinguengue', 123),
(403, 'Mucari', 124),
(404, 'Catala', 124),
(405, 'Caxinga', 124),
(406, 'Muquixe', 124),
(407, 'Quela', 125),
(408, 'Xandele', 125),
(409, 'Moma', 125),
(410, 'Bângalas', 125),
(411, 'Quirima', 126),
(412, 'Sautar', 126),
(413, 'Cazombo', 127),
(414, 'Nana Candundo', 127),
(415, 'Lumbala Caquengue', 127),
(416, 'Macondo', 127),
(417, 'Caianda', 127),
(418, 'Calunda', 127),
(419, 'Lóvua Leste', 127),
(420, 'Lumbala Guimbo', 128),
(421, 'Lutembo', 128),
(422, 'Chiume', 128),
(423, 'Luvuei', 128),
(424, 'Ninda', 128),
(425, 'Mussuma', 128),
(426, 'Sessa', 128),
(427, 'trcoa', 128),
(428, 'Camanongue', 128),
(429, 'Cameia', 129),
(430, 'Léua', 130),
(431, 'Liangongo', 130),
(432, 'Luau', 131),
(433, 'Luacano', 132),
(434, 'Lago-Dilolo', 132),
(435, 'Luchazes', 133),
(436, 'Cangombe', 133),
(437, 'Cassamba', 133),
(438, 'Tempué', 133),
(439, 'Muié', 133),
(440, 'Luena', 134),
(441, 'Cangumbe', 134),
(442, 'Cachipoque', 134),
(443, 'Lucusse', 134),
(444, 'Lutuai (antiga Muangai)', 134),
(445, 'Bibala', 135),
(446, 'Caitou', 135),
(447, 'Capangombe', 135),
(448, 'Lola', 135),
(449, 'Camucuio', 136),
(450, 'Mamué', 136),
(451, 'Chingo', 136),
(452, 'Moçâmedes', 137),
(453, 'Lucira', 137),
(454, 'Bentiaba', 137),
(455, 'Tômbua', 138),
(456, 'Iona', 138),
(457, 'São Martinho dos Tigres', 138),
(458, 'Virei', 139),
(459, 'Cainde', 139),
(460, 'Cangola', 140),
(461, 'Bengo', 140),
(462, 'Caiongo', 140),
(463, 'Nova Ambuíla', 141),
(464, 'Quipedro', 141),
(465, 'Bembe', 142),
(466, 'Lucunga', 142),
(467, 'Mabaia', 142),
(468, 'Buengas', 143),
(469, 'Nova Esperança (antiga Buenga Norte)', 143),
(470, 'Cuilo-Camboso', 143),
(471, 'Bungo', 144),
(472, 'Damba', 145),
(473, 'Mabanza Sosso', 145),
(474, 'Camatambo', 145),
(475, 'Lêmboa', 145),
(476, 'Petecusso', 145),
(477, 'Milunga', 146),
(478, 'Macocola', 146),
(479, 'Macolo', 146),
(480, 'Massau', 146),
(481, 'Maquela do Zombo', 147),
(482, 'Beu', 147),
(483, 'Cuilo Futa', 147),
(484, 'Quibocolo', 147),
(485, 'Sacandica', 147),
(486, 'Mucaba', 148),
(487, 'Uando', 148),
(488, 'Negage', 149),
(489, 'Dimuca', 149),
(490, 'Quisseque', 149),
(491, 'Puri', 150),
(492, 'Quimbele', 151),
(493, 'Cuango', 151),
(494, 'Icoca', 151),
(495, 'Alto Zaza', 151),
(496, 'Quitexe', 152),
(497, 'Aldeia Viçosa', 152),
(498, 'Cambamba', 152),
(499, 'Vista Alegre', 152),
(500, 'Sanza Pombo', 153),
(501, 'Cuilo Pombo', 153),
(502, 'Uamba', 153),
(503, 'Alfândega', 153),
(504, 'Songo', 154),
(505, 'Quivuenga', 154),
(506, 'Uíge', 156),
(507, 'Cuimba', 157),
(508, 'Buela', 157),
(509, 'Serra da Canda', 157),
(510, 'Luvaca', 157),
(511, 'Mbanza Congo', 158),
(512, 'Calambata', 158),
(513, 'Caluca', 158),
(514, 'Quiende', 158),
(515, 'Luvu', 158),
(516, 'Madimba', 158),
(517, 'Nóqui', 159),
(518, 'Lufico', 159),
(519, 'Mepala Lulendo', 159),
(520, 'Nezeto', 160),
(521, 'Mussera', 160),
(522, 'Quibala Norte', 160),
(523, 'Quindeje', 160),
(524, 'Soio', 161),
(525, 'Sumba', 161),
(526, 'Pedra de Feitiço', 161),
(527, 'Quêlo', 161),
(528, 'Mangue Grande', 161),
(529, 'Tomboco', 162),
(530, 'Quinsimba', 162),
(531, 'Quinzau', 162);

-- --------------------------------------------------------

--
-- Estrutura da tabela `gestor`
--

CREATE TABLE `gestor` (
  `gestor_id` int(11) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `gestor`
--

INSERT INTO `gestor` (`gestor_id`, `estado`) VALUES
(2, 'OLD'),
(70, 'NEW');

-- --------------------------------------------------------

--
-- Estrutura da tabela `municipio`
--

CREATE TABLE `municipio` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `provincia_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `municipio`
--

INSERT INTO `municipio` (`id`, `nome`, `provincia_id`) VALUES
(1, 'Ambriz', 1),
(2, 'Bula Atumba', 1),
(3, 'Dande', 1),
(4, 'Dembos', 1),
(5, 'Nambuangongo', 1),
(6, 'Pango Aluquém', 1),
(7, 'Baía Farta', 2),
(8, 'Balombo', 2),
(9, 'Benguela', 2),
(10, 'Bocoio', 2),
(11, 'Caimbambo', 2),
(12, 'Catumbela', 2),
(13, 'Chongoroi', 2),
(14, 'Cubal', 2),
(15, 'Ganda', 2),
(16, 'Lobito', 2),
(17, 'Andulo', 3),
(18, 'Camacupa', 3),
(19, 'Catabola', 3),
(20, 'Chinguar', 3),
(21, 'Chitembo', 3),
(22, 'Cuemba', 3),
(23, 'Cuíto', 3),
(24, 'Cunhinga', 3),
(25, 'Nharea', 3),
(26, 'Belize', 4),
(27, 'Buco-Zau', 4),
(28, 'Cabinda', 4),
(29, 'Cacongo', 4),
(30, 'Calai', 5),
(31, 'Cuangar', 5),
(32, 'Cuchi', 5),
(33, 'Cuito Cuanavale', 5),
(34, 'Dirico', 5),
(35, 'Mavinga', 5),
(36, 'Menongue', 5),
(37, 'Nancova', 5),
(38, 'Rivungo', 5),
(39, 'Ambaca', 6),
(40, 'Banga', 6),
(41, 'Bolongongo', 6),
(42, 'Cambambe', 6),
(43, 'Cazengo', 6),
(44, 'Golungo Alto', 6),
(45, 'Gonguembo', 6),
(46, 'Lucala', 6),
(47, 'Quiculungo', 6),
(48, 'Samba Caju', 6),
(49, 'Amboim', 7),
(50, 'Cassongue', 7),
(51, 'Cela', 7),
(52, 'Conda', 7),
(53, 'Ebo', 7),
(54, 'Mussende', 7),
(55, 'Porto Amboim', 7),
(56, 'Quibala', 7),
(57, 'Quilenda', 7),
(58, 'Seles', 7),
(59, 'Sumbe', 7),
(60, 'Cahama', 8),
(61, 'Cuanhama', 8),
(62, 'Curoca', 8),
(63, 'Cuvelai', 8),
(64, 'Namacunde', 8),
(65, 'Ombadija', 8),
(66, 'Bailundo', 9),
(67, 'Caála', 9),
(68, 'Cachiungo', 9),
(69, 'Chicala-Choloanga', 9),
(70, 'Chinjenje', 9),
(71, 'Ecunha', 9),
(72, 'Huambo', 9),
(73, 'Londuimbali', 9),
(74, 'Longonjo', 9),
(75, 'Mungo', 9),
(76, 'Ucuma', 9),
(77, 'Caconda', 10),
(78, 'Caluquembe', 10),
(79, 'Chiange', 10),
(80, 'Chibia', 10),
(81, 'Chicomba', 10),
(82, 'Chipindo', 10),
(83, 'Cuvango', 10),
(84, 'Humpata', 10),
(85, 'Jamba', 10),
(86, 'Lubango', 10),
(87, 'Matala', 10),
(88, 'Quilengues', 10),
(89, 'Quipungo', 10),
(90, 'Belas', 11),
(91, 'Cacuaco', 11),
(92, 'Cazenga', 11),
(93, 'Ícolo e Bengo', 11),
(94, 'Luanda', 11),
(95, 'Quilamba Quiaxi', 11),
(96, 'Quissama', 11),
(97, 'Talatona', 11),
(98, 'Viana', 11),
(99, 'Cambulo', 12),
(100, 'Capenda Camulemba', 12),
(101, 'Caungula', 12),
(102, 'Chitato', 12),
(103, 'Cuango', 12),
(104, 'Cuílo', 12),
(105, 'Lóvua', 12),
(106, 'Lubalo', 12),
(107, 'Lucapa', 12),
(108, 'Xá-Muteba', 12),
(109, 'Cacolo', 13),
(110, 'Dala', 13),
(111, 'Muconda', 13),
(112, 'Saurimo', 13),
(113, 'Cacuso', 14),
(114, 'Cambundi Catembo', 14),
(115, 'Cangandala', 14),
(116, 'Caombo', 14),
(117, 'Cuaba Nzoji', 14),
(118, 'Cunda-Dia-Baze', 14),
(119, 'Calandula', 14),
(120, 'Luquembo', 14),
(121, 'Malanje', 14),
(122, 'Marimba', 14),
(123, 'Massango', 14),
(124, 'Mucari', 14),
(125, 'Quela', 14),
(126, 'Quirima', 14),
(127, 'Alto Zambeze', 15),
(128, 'Bundas', 15),
(129, 'Camanongue', 15),
(130, 'Cameia', 15),
(131, 'Léua', 15),
(132, 'Luau', 15),
(133, 'Luacano', 15),
(134, 'Luchazes', 15),
(135, 'Moxico', 15),
(136, 'Bibala', 16),
(137, 'Camucuio', 16),
(138, 'Moçâmedes', 16),
(139, 'Tômbua', 16),
(140, 'Virei', 16),
(141, 'Alto Cauale', 17),
(142, 'Ambuíla', 17),
(143, 'Bembe', 17),
(144, 'Buengas', 17),
(145, 'Bungo', 17),
(146, 'Damba', 17),
(147, 'Milunga', 17),
(148, 'Maquela do Zombo', 17),
(149, 'Mucaba', 17),
(150, 'Negage', 17),
(151, 'Puri', 17),
(152, 'Quimbele', 17),
(153, 'Quitexe', 17),
(154, 'Sanza Pombo', 17),
(155, 'Songo', 17),
(156, 'Uíge', 17),
(157, 'Cuimba', 18),
(158, 'Mabanza Congo', 18),
(159, 'Nóqui', 18),
(160, 'Nezeto', 18),
(161, 'Soio', 18),
(162, 'Tomboco', 18);

-- --------------------------------------------------------

--
-- Estrutura da tabela `nacionalidade`
--

CREATE TABLE `nacionalidade` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `nacionalidade`
--

INSERT INTO `nacionalidade` (`id`, `nome`) VALUES
(1, 'afegão'),
(2, 'andorrano'),
(3, 'angolano'),
(4, 'antiguano'),
(5, 'argelino'),
(6, ' argentino'),
(7, ' armênio'),
(8, ' australiano'),
(9, 'austríaco'),
(10, 'azeri '),
(11, ' bahamense'),
(12, ' bangladês'),
(13, 'barbadiano'),
(14, ' baremita'),
(15, ' bielorrusso'),
(16, ' belga'),
(17, 'belizenho'),
(18, ' beninense'),
(19, ' boliviano'),
(20, 'bósnio'),
(21, ' bechuano'),
(22, 'brasileiro'),
(23, 'bruneano'),
(24, 'búlgaro'),
(25, ' burquinense'),
(26, 'burundês '),
(27, ' butanense'),
(28, 'cabo-verdiano '),
(29, 'camaronense '),
(30, 'cambojano '),
(31, 'canadense '),
(32, 'centroafricano '),
(33, 'chadiano '),
(34, 'chinês '),
(35, ' chileno'),
(36, 'cookiano '),
(37, 'colombiano '),
(38, ' comoriano'),
(39, ' costa-riquenho'),
(40, 'croata '),
(41, 'Cubano '),
(42, 'cipriota '),
(43, 'tcheco '),
(44, ' congolense'),
(45, ' dinamarquês'),
(46, 'djibutiense '),
(47, 'dominiquense '),
(48, 'dominicano '),
(49, 'timorense '),
(50, ' equatoriano'),
(51, ' egípcio'),
(52, 'salvadorenho '),
(53, ' inglês'),
(54, 'guinéu-equatoriano '),
(55, 'eritreu '),
(56, ' estoniano'),
(57, 'fijiano '),
(58, ' finlandês'),
(59, ' francês'),
(60, 'gabonense '),
(61, ' gambiano'),
(62, ' geórgico'),
(63, ' alemão'),
(64, 'granadino '),
(65, 'grego '),
(66, ' guatemalteco'),
(67, ' guineano'),
(68, ' guineense'),
(69, 'guianense '),
(70, ' haitiano'),
(71, 'holandês '),
(72, 'hondurenho '),
(73, ' húngaro'),
(74, ' islandês'),
(75, 'indiano '),
(76, 'indonésio '),
(77, ' iraniano'),
(78, ' irlandês'),
(79, ' israelita'),
(80, ' italiano'),
(81, 'costa-marfinense '),
(82, 'jamaicano '),
(83, 'japonês '),
(84, 'jordão '),
(85, ' cazaque'),
(86, ' queniano'),
(87, ' quiribatiano'),
(88, ' quirguistanês'),
(89, 'kuwaitiano '),
(90, 'laosiano '),
(91, ' letoniano'),
(92, 'libanês '),
(93, ' lesotiano'),
(94, 'liberiano '),
(95, ' liechtensteinense'),
(96, 'lituano '),
(97, 'luxemburguês '),
(98, 'líbio '),
(99, ' macedônio'),
(100, ' madagascarense'),
(101, 'malaio '),
(102, ' malauiano'),
(103, 'maldivo '),
(104, ' maliano'),
(105, ' maltês'),
(106, 'mauriciano '),
(107, ' mauritano'),
(108, ' marshallino'),
(109, ' micronésio'),
(110, 'mexicano '),
(111, 'marroquino '),
(112, ' moldávio'),
(113, ' monegasco'),
(114, ' mongol'),
(115, 'montenegrino '),
(116, 'moçambicano '),
(117, 'birmanês '),
(118, ' namibiano'),
(119, 'nauruano '),
(120, 'nepalês '),
(121, 'neozelandês '),
(122, ' nicaraguense'),
(123, 'nigerino '),
(124, ' nigeriano'),
(125, ' niuano'),
(126, ' norte-coreano'),
(127, ' norueguês'),
(128, ' omanense'),
(129, ' palestino'),
(130, ' paquistanês'),
(131, ' palauense'),
(132, 'panamenho '),
(133, 'papuásio '),
(134, ' paraguaio'),
(135, ' peruano'),
(136, 'filipino '),
(137, ' polonês'),
(138, ' português'),
(139, 'catarense '),
(140, ' romeno'),
(141, 'russo '),
(142, ' ruandês'),
(143, 'samoano '),
(144, ' santa-lucense'),
(145, 'são-cristovense '),
(146, ' são-marinense'),
(147, 'são-tomense '),
(148, 'são-vicentino '),
(149, 'escocês '),
(150, ' senegalense'),
(151, 'sérvio '),
(152, 'seichelense '),
(153, 'serra-leonês '),
(154, ' singapurense'),
(155, ' eslovaco'),
(156, ' salomônico'),
(157, ' somali'),
(158, 'sul–africano '),
(159, 'coreano '),
(160, ' sul-sudanense'),
(161, 'espanhol '),
(162, 'srilankês '),
(163, ' sudanense'),
(164, ' surinamês'),
(165, ' suazi'),
(166, 'sueco '),
(167, ' suíço'),
(168, ' sírio'),
(169, 'tajique '),
(170, 'tanzaniano '),
(171, ' tailandês'),
(172, 'togolês '),
(173, 'tonganês '),
(174, ' trinitário'),
(175, ' tunisiano'),
(176, ' turcomeno'),
(177, 'turco '),
(178, ' tuvaluano'),
(179, 'ucraniano '),
(180, ' ugandês'),
(181, 'uruguaio '),
(182, ' árabe'),
(183, ' britânico'),
(184, ' americano '),
(185, ' uzbeque'),
(186, ' vanuatuano'),
(187, 'venezuelano '),
(188, ' vietnamita'),
(189, ' galês'),
(190, ' iemenita'),
(191, 'zambiano '),
(192, 'zimbabueano ');

-- --------------------------------------------------------

--
-- Estrutura da tabela `outdoors`
--

CREATE TABLE `outdoors` (
  `id` int(11) NOT NULL,
  `tipoOutdoor` varchar(50) NOT NULL,
  `preco` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `comuna` varchar(50) NOT NULL,
  `imagem` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `outdoors`
--

INSERT INTO `outdoors` (`id`, `tipoOutdoor`, `preco`, `estado`, `provincia`, `municipio`, `comuna`, `imagem`) VALUES
(14, 'Placas Luminosas', '40.000,00', 'disponivel', 'Bié', 'Camacupa', 'Santo António da Muinha', 0x0000001c667479706176696600000000617669666d6966316d696166000000ea6d657461000000000000002168646c72000000000000000070696374000000000000000000000000000000000e7069746d00000000000100000022696c6f630000000044400001000100000000010e000100000000000010440000002369696e6600000000000100000015696e6665020000000001000061763031000000006a697072700000004b6970636f00000013636f6c726e636c78000200020006800000000c6176314381010c0000000014697370650000000000000272000001a2000000107069786900000000030808080000001769706d610000000000000001000104818203840000104c6d64617412000a0a1866271d0b0408081a1032b32044500041041050d8029099559722499e3f5843e2d899848a016d6251b14cdb97cd1941c9bd5feb9e3300e00ad0ba579c133265d97fa047fed3a68e8714354317e68f3b5b4137a5c6d0d6964bb449a4adb151f605627471b61a835e01f1e3738e54b951cb269e910747b3123058d94e35e7c4dee07998930f6dcf2026dde0469ab4b1b080a3df4417c8054045be235291b211975fb7103afd065b57fea0b62cee9ab115e012e91c2509fe8aeb56912be3761c28e99ecf7cd04dd6278fade754efb9601d5463aac54807c34cd5f2e59e9dfb83998556ec42be3237bd88caa5c574f33953cff8c8fda6bafb168fbb79885c402565fa9234d941cf65422da58d0494ad73cb80657fe7ed8a63caed3e08d0c55c02a22ae7d00e0afcb6b2150b91b1fd23ce258fd76518bc897d7593bc88d5cade7653d624b134cd3daf9dfbbeb25b16eb8bbba802772a084d4d4734ab1b3a55576f3f2503a0356d8f1bac62ea8c6a1fdd206ee5892c2f87d3771c4dca911f9916433f14bf6e0cad8da139fc6f51b520cfc6c7262b00b6a4d441e1216a6ff5a8969958a06183fa88742a2d752fe6db4c7302b1efa6206537e385b90ce7cbeeeb882d49e77147e624ea4aaccaa2638c787bc7811cb16555eaf46641100aa253ecfa3da41ded79df6535b43d6e075c9ab9e49274c720995e1507b78d437a42b5746e60bcf2ad6d787e0ac87948ef4727fd87e0ffc60e88520fc1a042a3f84b58c278ae3b58e36a6fea72dbb9148247cc0e8d7c34a702180daa6970a479c15b02ca1a282ecc59b818428887777bf62c84692055b6730b83652d65556f8c3f1db13b312e87e960360c645134a2ab544d0a3d70d49ee33997963214cd265109b341d3b9e0e21beb7f13a8541aa60074d6d3cf89ff233f2e0e7f4a4104bca205e0e3492f13061c9bdf0962ea0f23e18fca6b0e07889442ea6d370109674a1fe68253b7c3b171435fa2edac5757cb8e843570101d57ca64a10f8001bcb53c08b7d4eb59710c7d021a405811a17c53f7c78fcbd249fe082828fec01deca0d8444434b4a0a5fc753886fd5a738b6a34369bd77956ba7462c24183fae58546efe3e52df078f247d2dbdaee25c1552de5e1fb19a3e0b22c264e234e0cb70af9246aee12b34404227aff6c4c1ac965144ac56185cd10abb00dce7cc6babf09378dfb3919d1b7d1ced09de0c4cb439e2eb8e2dc0f3e86aaf6fcb41a8005d62e45ad32f2e9d9388e358e5d26006d2a2a0e73521b5eea3dbf1456e07042202612120106f1249d2a3485e06ab350426686dd6a6ca1a45063a962f1489bfafd3695486edc82fa2d354397a1c79a2bb14c8f802bfa3af0276ea83b80c2881368c1f9a02adbc215574b54c40cc6292ec889f8814b1f36a6626f9cfa02e550740f4d8f5e1fa9822f7f586780be322f3f2146907047fa987808ee39620b4f803e4eca3c2a74da1eae8966dd092c2cfebb03ec850c919685d5dfdcc7f8969d40f8aa8560af522d940c765a83cef2350421eb1daf71d3aadbc1b22ddb4ce725960ec0183ef6966e06e62b4e6975e535b5be7d6a3b4f739d3a12bf6d2daffd1205a4c92becdd05b9e3aae6e168447b9b6cf5e70a96dd601793b2f01059c50384fe72d1f2d3c93068cfb34e668ec635265f18d5668d3d1327efa60b9f26adbd4e0f0675ef5e3021558ae9c7e99a936efd8717606a8f2922f3772d8e197fc83d3805f3fe7c3e0f2ebce2cbb6806c8de8b3bd3b492cf4a59f5e904e1a7fbc204e68deaadcce1751d5f9433171062978109f5a0bccf19bc287088a61437c32627e6c25b21a6172cb722fd30302389f8326aabf95daca43d67f3f5826c3574d8d2d71b560b422b63462c08fb2873e0fa293e9fe5ea6f1868de98d2e5373c742795cb2296d86fb083ad13f8ebdc5872b127bbadb6c89e0c9e70bd320fce6533bab4d439c5650c3a239a57fe4ab67cec8667ac53bd4b6eae44becc1c72a148256992699a61f25fcdf09d5ec2cb241998b980aebce5a2679fb8cdeda8802211eb6a8cfbb91f630cc0472a7a0a0381fd7123c6d0a2856200ca7ba89db59769d7190b8a41c6bba822b077015f09f4bb90cfe8e6857938e87c0b84c8ee8c82158753870c8aff75ecef4b71a55b5a71f0da458d6c3e0eea7e87ab895dcab467b99cacaa6836440fb4aa2d102f9b60ef871b9093afe1af5e19d24f3a23ca12e0cbed42138ac7f096e7d707431648c186cb1b0455d79c19b143e19ac642cb8113942f5b4cca3ab64151620ceaac9d5c43eb15e77007903ce3c3f6d3617c6c2cd62cfc758769bb82fe62a277422eba3f4ecd256b40bd34f7476861f92e61ae882f75c766237556e18e943553e79c857c32c338e6b090607802033cb35b788598e9944a1a8d8a110428a8b7c310d66a82a4845beae4c809bed3320a9cfe687ab290693611ba314e3c5a9a9f018dfd2679c77f5e8a6567ff9c7f1158335827026f9377d76a4b7392fe12de5ea9b01d23e0aefc16ed8188f7637f95bd2efa25c6d2df33dc15bb9e9c5ad3d5817b11afa9fc0529015499ee5ab882c2215037f638deb4c72c7cf849ec506dcfe2c009b3c536e24b0d0713f03920ab892ca18a6af7569ab21772981df404c33cb72b747fa4387e8e8801787f09032fff9a50fe3b5f47802ee4728add8a82a982633435ceafebb6d9a30f5b88b8f00838e045eaac408bff64a944e0a930052bd73fb81c724c9e8cd5b3ded24cab6c5427b661ce8d48feae4081b1991f1e718821af9192444d924f5c22c367780a6af9f18b468367bceb05f60866f75d2b639951c4f93978f76448130ab41f23c3ecf9ab5e60185c732ae1d10937218bd20bbc5300bb4790b8c95221f300e9482cf49556e28f37f8eccb8a36072fa2e857b8932fe4ee2314a70917f880a713cba5e33f40787447ca409cfa4664a2ab8e0d2b637ad4de89e97f4ad8113dddb7a1130efbbf2f05855c050af9e62b1aa92c6d3b78de5c4b03d5467f213b1992bd65232f12a7c61838b141cc03fb160fb37e74de384e36311ec8ce79ad611385bc6fc26ff98e839ab409d5330202d85959111f15931dfdc4b669eebb510d4e26bb9fd3bea6474847c25e348cda35a53207ccb55abddc9768b7fe90e821533b0a3b7853f6968a73b33bbcce08cd1dc2109cd4bd02eec4f3b529eaf2817dd37e0f30c91fe41349035cd50505dc852d9aa1aff72294d899ca4c6ecfe54bdcd0e9a666f23f23c08dfad3c6c94791ec42ca6bcfe904dda436c80171591d307ddc5ebe4cd4421b7d8d26d7093c637e4d29989140ecd109ca421baf3188c582440459ae9af82c2f231706c9c351026a97589573e396848c16a37b8278c1bc738c0d37429bba1c2089281e59c4977b9e1026161857b0e2bb8f096b5865a49e4a5b2870e549f9a04d221a54167e4dbb4bfee39e6f71fdb7d9e7857e62a652f769ea1a2c4398ce3e6d179d7ff3a222c57150dbc41839a3c5d6172db6a258fd6a58d445ea7f834ad6ce80c389f38438ea6dc77bd081be10f6c45440b2a9ce62f19bc77991492c8594c92a5585e6fcb82b960971220f882ed7919fb2068afc91f7b2a1e62a92bd81770d65a2ff0716534dbc63936d4d6dfaf93d6e08187de4eb000100ce3d4c29ed801fac741bcc067c2b2df2e05d1b1296c747cbfdd6b75831dfb37e21240cc9895871f6f63b9b1bbdaeead3ccfddc254bf1b0ea5970eb7c12e49ceda182dc6b435653e8c6c77cf3670b3830b2804e1a999101b1354fb33757e5415c0ef256627e2bafe7b0692530f5b02fe60ca55fabb94ce4b6ea30048595c8c76e16103fccd1720067e4832bf48965ca1b409ef28d221e790ff07f2732ceb4647daf7f7519901564fc280415a0d47385171ed6b529e3d36b8eb9722f67878a661de9f80ccab9dfe41fefa2b6c17199dc6bbf71a38e51a38e99d72c9740fc4b16753a5f1a2293df56aa2e436aa909c811e4a25647368167123b399fd387b0f4661a946def2effe954057956d328cc1a0365fdbc1d53870ff0c0a042eb453cf32ce026e4c1f365ea7d481a21723fc68f44faad9527ccf5e3a2a7d865fc119193a1e762092dd4fe27048202430982f72250dfc9d537232eb8ddf0ffec173b3cdb88b316474b15aa7d05da3f04fb9632d4df9c5d393fbcb3d367c9592cd8d07393bea0033af6a6418b8282f572fce0294866bc50b2121e4d9e676cdd669b90e625d41d43b9e424fd56568b49325a99c383c4fc089e11c2ef1157fe8805e97b01f477004acb068fff569902b58dbfa55ca1fc1b10c4b0c843ff6104e3ca0083d01253825d409fcc320bf3865e66d482466965f6b4acbda57c6455b4df131fdd0defd152e04695a93aaf367bad779a868dfacb63510b714898830709cacf81204585bd8e4379d395ecd758dedaba9ae69009f24d8a85a22e63b6f7c67dbc1aacffec801b73cdbcbd914f6eb47c9e262227130285313cb64d9a926fdd1e3c91a0e549e82ba7cba6e948a47917e35aa2d90f4b1a2749a5a313f118f8220fd4a27ed86ee1d9baca20939f7f4059076a41c986f6c11f719f5f3957e865bbf1b8958556c8755f9ded9558b6db83f1add8b900518e26a229c8103f61cfff7d61590f6de36428ad57e272759ca7f71f389ffc0fe0a5547fa9776bf108b0533e9fe14ed0b035506d435545a5d6fefad4b07ea118d94ebc8da090bdf07083d51bf8eaf5b7d669403e30f6d804e04beae4cceab6b92d13c243f6f66e70bb662ec83cc327165d0243e2290b76f48d56123abe1f716eae9f0a6c6dd1aac8a15b5823f03a8535a09fc2530d6de4f149099e44bb970a5b5560519a71f09e3106a100ceec4f594e373bf829c3e2dac4c4b61c6f44843168dc88f372a52aec1c2afc0823ad887c7ae1389ba06786dbafb9688230ce18316b984a2370ea3d321c48874b9403792b86b17ca1f77fdf5cfde303b3f7716dbb94ee2f9ea8962979bad44038bf1bac71ac7696a6da9d3889de513ce3aa23faa940b9d62092422db03307b4325945225f335316f271dbec955fe14574da0857aa0d72a095ba6c0f27fe604a6e4d65ec76f1b2970b52f0e37ffacace1fc53f0faa37a858defd4e0e0d0cb201f08cdf3fd238fd85878820995c780d9753901545438308074e159f1694a31e61429d0cc40c49ef221b2b7453e19d2add91136073e253fffd09df40850a838b5e6619cb363c62e024006021d0638e5682516ff77421108c86e4bbdb6e9712393bf4d24a890f20a9eebb5f6f646774cba3b8ce03fc6e804f3e91b3a339454f30d4b5a67d4a6af6381c2b002bdadb66fe450962132dd4941e4ec63d3a2345ea910a9b015e17315f85c440cbfd677a23f40e821769c6644b0baa87db53e1546f99e909d30c52b1f4200ed8ab8829afe8815a0dcab6c7b83508eb7d44cbc788adf1a51b143a857d00c5ed3b506a1356d725a1767c2e8070bdc0980ce9c4549b5f83fb035ec920f04876c199c651b003695d6056c099eb02e38e909d41f674d69189a48e38696acc81d75e4d0741e48571e1148fc741c091fe2f1ec5e6fca024230a4f9600293ce6fb2be43ae819757fcb7dbdbd476db90d1f0c3306666af6e9456731848a7cce3f6f5bd47c94c56909787e69145d28929f80e19f8b4e750a54d1dda1d1d390a3107bb9a8414d9aa7bb649f91c5febb4705f4172028071e00a59b56ea694b6bc8b782a563c460b1e92484afd39dd6ef13c2cdc09c729334d4515c72436f7bb263f30d64472a188a660a64c7bc58dfd9dbb5fac48cb1b52f0da0c1f8c8bda266493c01a84c7c5634fa2bb962ba84095241df90fa8d5492aeea2d66de3b2e88898666ee3bff3b6ac73908a7770),
(15, 'Placas Nao Luminosas', '30.000,00', 'disponivel', 'Luanda', 'Luanda', 'Luanda', 0x0000001c667479706176696600000000617669666d6966316d696166000000ea6d657461000000000000002168646c72000000000000000070696374000000000000000000000000000000000e7069746d00000000000100000022696c6f630000000044400001000100000000010e000100000000000010440000002369696e6600000000000100000015696e6665020000000001000061763031000000006a697072700000004b6970636f00000013636f6c726e636c78000200020006800000000c6176314381010c0000000014697370650000000000000272000001a2000000107069786900000000030808080000001769706d610000000000000001000104818203840000104c6d64617412000a0a1866271d0b0408081a1032b32044500041041050d8029099559722499e3f5843e2d899848a016d6251b14cdb97cd1941c9bd5feb9e3300e00ad0ba579c133265d97fa047fed3a68e8714354317e68f3b5b4137a5c6d0d6964bb449a4adb151f605627471b61a835e01f1e3738e54b951cb269e910747b3123058d94e35e7c4dee07998930f6dcf2026dde0469ab4b1b080a3df4417c8054045be235291b211975fb7103afd065b57fea0b62cee9ab115e012e91c2509fe8aeb56912be3761c28e99ecf7cd04dd6278fade754efb9601d5463aac54807c34cd5f2e59e9dfb83998556ec42be3237bd88caa5c574f33953cff8c8fda6bafb168fbb79885c402565fa9234d941cf65422da58d0494ad73cb80657fe7ed8a63caed3e08d0c55c02a22ae7d00e0afcb6b2150b91b1fd23ce258fd76518bc897d7593bc88d5cade7653d624b134cd3daf9dfbbeb25b16eb8bbba802772a084d4d4734ab1b3a55576f3f2503a0356d8f1bac62ea8c6a1fdd206ee5892c2f87d3771c4dca911f9916433f14bf6e0cad8da139fc6f51b520cfc6c7262b00b6a4d441e1216a6ff5a8969958a06183fa88742a2d752fe6db4c7302b1efa6206537e385b90ce7cbeeeb882d49e77147e624ea4aaccaa2638c787bc7811cb16555eaf46641100aa253ecfa3da41ded79df6535b43d6e075c9ab9e49274c720995e1507b78d437a42b5746e60bcf2ad6d787e0ac87948ef4727fd87e0ffc60e88520fc1a042a3f84b58c278ae3b58e36a6fea72dbb9148247cc0e8d7c34a702180daa6970a479c15b02ca1a282ecc59b818428887777bf62c84692055b6730b83652d65556f8c3f1db13b312e87e960360c645134a2ab544d0a3d70d49ee33997963214cd265109b341d3b9e0e21beb7f13a8541aa60074d6d3cf89ff233f2e0e7f4a4104bca205e0e3492f13061c9bdf0962ea0f23e18fca6b0e07889442ea6d370109674a1fe68253b7c3b171435fa2edac5757cb8e843570101d57ca64a10f8001bcb53c08b7d4eb59710c7d021a405811a17c53f7c78fcbd249fe082828fec01deca0d8444434b4a0a5fc753886fd5a738b6a34369bd77956ba7462c24183fae58546efe3e52df078f247d2dbdaee25c1552de5e1fb19a3e0b22c264e234e0cb70af9246aee12b34404227aff6c4c1ac965144ac56185cd10abb00dce7cc6babf09378dfb3919d1b7d1ced09de0c4cb439e2eb8e2dc0f3e86aaf6fcb41a8005d62e45ad32f2e9d9388e358e5d26006d2a2a0e73521b5eea3dbf1456e07042202612120106f1249d2a3485e06ab350426686dd6a6ca1a45063a962f1489bfafd3695486edc82fa2d354397a1c79a2bb14c8f802bfa3af0276ea83b80c2881368c1f9a02adbc215574b54c40cc6292ec889f8814b1f36a6626f9cfa02e550740f4d8f5e1fa9822f7f586780be322f3f2146907047fa987808ee39620b4f803e4eca3c2a74da1eae8966dd092c2cfebb03ec850c919685d5dfdcc7f8969d40f8aa8560af522d940c765a83cef2350421eb1daf71d3aadbc1b22ddb4ce725960ec0183ef6966e06e62b4e6975e535b5be7d6a3b4f739d3a12bf6d2daffd1205a4c92becdd05b9e3aae6e168447b9b6cf5e70a96dd601793b2f01059c50384fe72d1f2d3c93068cfb34e668ec635265f18d5668d3d1327efa60b9f26adbd4e0f0675ef5e3021558ae9c7e99a936efd8717606a8f2922f3772d8e197fc83d3805f3fe7c3e0f2ebce2cbb6806c8de8b3bd3b492cf4a59f5e904e1a7fbc204e68deaadcce1751d5f9433171062978109f5a0bccf19bc287088a61437c32627e6c25b21a6172cb722fd30302389f8326aabf95daca43d67f3f5826c3574d8d2d71b560b422b63462c08fb2873e0fa293e9fe5ea6f1868de98d2e5373c742795cb2296d86fb083ad13f8ebdc5872b127bbadb6c89e0c9e70bd320fce6533bab4d439c5650c3a239a57fe4ab67cec8667ac53bd4b6eae44becc1c72a148256992699a61f25fcdf09d5ec2cb241998b980aebce5a2679fb8cdeda8802211eb6a8cfbb91f630cc0472a7a0a0381fd7123c6d0a2856200ca7ba89db59769d7190b8a41c6bba822b077015f09f4bb90cfe8e6857938e87c0b84c8ee8c82158753870c8aff75ecef4b71a55b5a71f0da458d6c3e0eea7e87ab895dcab467b99cacaa6836440fb4aa2d102f9b60ef871b9093afe1af5e19d24f3a23ca12e0cbed42138ac7f096e7d707431648c186cb1b0455d79c19b143e19ac642cb8113942f5b4cca3ab64151620ceaac9d5c43eb15e77007903ce3c3f6d3617c6c2cd62cfc758769bb82fe62a277422eba3f4ecd256b40bd34f7476861f92e61ae882f75c766237556e18e943553e79c857c32c338e6b090607802033cb35b788598e9944a1a8d8a110428a8b7c310d66a82a4845beae4c809bed3320a9cfe687ab290693611ba314e3c5a9a9f018dfd2679c77f5e8a6567ff9c7f1158335827026f9377d76a4b7392fe12de5ea9b01d23e0aefc16ed8188f7637f95bd2efa25c6d2df33dc15bb9e9c5ad3d5817b11afa9fc0529015499ee5ab882c2215037f638deb4c72c7cf849ec506dcfe2c009b3c536e24b0d0713f03920ab892ca18a6af7569ab21772981df404c33cb72b747fa4387e8e8801787f09032fff9a50fe3b5f47802ee4728add8a82a982633435ceafebb6d9a30f5b88b8f00838e045eaac408bff64a944e0a930052bd73fb81c724c9e8cd5b3ded24cab6c5427b661ce8d48feae4081b1991f1e718821af9192444d924f5c22c367780a6af9f18b468367bceb05f60866f75d2b639951c4f93978f76448130ab41f23c3ecf9ab5e60185c732ae1d10937218bd20bbc5300bb4790b8c95221f300e9482cf49556e28f37f8eccb8a36072fa2e857b8932fe4ee2314a70917f880a713cba5e33f40787447ca409cfa4664a2ab8e0d2b637ad4de89e97f4ad8113dddb7a1130efbbf2f05855c050af9e62b1aa92c6d3b78de5c4b03d5467f213b1992bd65232f12a7c61838b141cc03fb160fb37e74de384e36311ec8ce79ad611385bc6fc26ff98e839ab409d5330202d85959111f15931dfdc4b669eebb510d4e26bb9fd3bea6474847c25e348cda35a53207ccb55abddc9768b7fe90e821533b0a3b7853f6968a73b33bbcce08cd1dc2109cd4bd02eec4f3b529eaf2817dd37e0f30c91fe41349035cd50505dc852d9aa1aff72294d899ca4c6ecfe54bdcd0e9a666f23f23c08dfad3c6c94791ec42ca6bcfe904dda436c80171591d307ddc5ebe4cd4421b7d8d26d7093c637e4d29989140ecd109ca421baf3188c582440459ae9af82c2f231706c9c351026a97589573e396848c16a37b8278c1bc738c0d37429bba1c2089281e59c4977b9e1026161857b0e2bb8f096b5865a49e4a5b2870e549f9a04d221a54167e4dbb4bfee39e6f71fdb7d9e7857e62a652f769ea1a2c4398ce3e6d179d7ff3a222c57150dbc41839a3c5d6172db6a258fd6a58d445ea7f834ad6ce80c389f38438ea6dc77bd081be10f6c45440b2a9ce62f19bc77991492c8594c92a5585e6fcb82b960971220f882ed7919fb2068afc91f7b2a1e62a92bd81770d65a2ff0716534dbc63936d4d6dfaf93d6e08187de4eb000100ce3d4c29ed801fac741bcc067c2b2df2e05d1b1296c747cbfdd6b75831dfb37e21240cc9895871f6f63b9b1bbdaeead3ccfddc254bf1b0ea5970eb7c12e49ceda182dc6b435653e8c6c77cf3670b3830b2804e1a999101b1354fb33757e5415c0ef256627e2bafe7b0692530f5b02fe60ca55fabb94ce4b6ea30048595c8c76e16103fccd1720067e4832bf48965ca1b409ef28d221e790ff07f2732ceb4647daf7f7519901564fc280415a0d47385171ed6b529e3d36b8eb9722f67878a661de9f80ccab9dfe41fefa2b6c17199dc6bbf71a38e51a38e99d72c9740fc4b16753a5f1a2293df56aa2e436aa909c811e4a25647368167123b399fd387b0f4661a946def2effe954057956d328cc1a0365fdbc1d53870ff0c0a042eb453cf32ce026e4c1f365ea7d481a21723fc68f44faad9527ccf5e3a2a7d865fc119193a1e762092dd4fe27048202430982f72250dfc9d537232eb8ddf0ffec173b3cdb88b316474b15aa7d05da3f04fb9632d4df9c5d393fbcb3d367c9592cd8d07393bea0033af6a6418b8282f572fce0294866bc50b2121e4d9e676cdd669b90e625d41d43b9e424fd56568b49325a99c383c4fc089e11c2ef1157fe8805e97b01f477004acb068fff569902b58dbfa55ca1fc1b10c4b0c843ff6104e3ca0083d01253825d409fcc320bf3865e66d482466965f6b4acbda57c6455b4df131fdd0defd152e04695a93aaf367bad779a868dfacb63510b714898830709cacf81204585bd8e4379d395ecd758dedaba9ae69009f24d8a85a22e63b6f7c67dbc1aacffec801b73cdbcbd914f6eb47c9e262227130285313cb64d9a926fdd1e3c91a0e549e82ba7cba6e948a47917e35aa2d90f4b1a2749a5a313f118f8220fd4a27ed86ee1d9baca20939f7f4059076a41c986f6c11f719f5f3957e865bbf1b8958556c8755f9ded9558b6db83f1add8b900518e26a229c8103f61cfff7d61590f6de36428ad57e272759ca7f71f389ffc0fe0a5547fa9776bf108b0533e9fe14ed0b035506d435545a5d6fefad4b07ea118d94ebc8da090bdf07083d51bf8eaf5b7d669403e30f6d804e04beae4cceab6b92d13c243f6f66e70bb662ec83cc327165d0243e2290b76f48d56123abe1f716eae9f0a6c6dd1aac8a15b5823f03a8535a09fc2530d6de4f149099e44bb970a5b5560519a71f09e3106a100ceec4f594e373bf829c3e2dac4c4b61c6f44843168dc88f372a52aec1c2afc0823ad887c7ae1389ba06786dbafb9688230ce18316b984a2370ea3d321c48874b9403792b86b17ca1f77fdf5cfde303b3f7716dbb94ee2f9ea8962979bad44038bf1bac71ac7696a6da9d3889de513ce3aa23faa940b9d62092422db03307b4325945225f335316f271dbec955fe14574da0857aa0d72a095ba6c0f27fe604a6e4d65ec76f1b2970b52f0e37ffacace1fc53f0faa37a858defd4e0e0d0cb201f08cdf3fd238fd85878820995c780d9753901545438308074e159f1694a31e61429d0cc40c49ef221b2b7453e19d2add91136073e253fffd09df40850a838b5e6619cb363c62e024006021d0638e5682516ff77421108c86e4bbdb6e9712393bf4d24a890f20a9eebb5f6f646774cba3b8ce03fc6e804f3e91b3a339454f30d4b5a67d4a6af6381c2b002bdadb66fe450962132dd4941e4ec63d3a2345ea910a9b015e17315f85c440cbfd677a23f40e821769c6644b0baa87db53e1546f99e909d30c52b1f4200ed8ab8829afe8815a0dcab6c7b83508eb7d44cbc788adf1a51b143a857d00c5ed3b506a1356d725a1767c2e8070bdc0980ce9c4549b5f83fb035ec920f04876c199c651b003695d6056c099eb02e38e909d41f674d69189a48e38696acc81d75e4d0741e48571e1148fc741c091fe2f1ec5e6fca024230a4f9600293ce6fb2be43ae819757fcb7dbdbd476db90d1f0c3306666af6e9456731848a7cce3f6f5bd47c94c56909787e69145d28929f80e19f8b4e750a54d1dda1d1d390a3107bb9a8414d9aa7bb649f91c5febb4705f4172028071e00a59b56ea694b6bc8b782a563c460b1e92484afd39dd6ef13c2cdc09c729334d4515c72436f7bb263f30d64472a188a660a64c7bc58dfd9dbb5fac48cb1b52f0da0c1f8c8bda266493c01a84c7c5634fa2bb962ba84095241df90fa8d5492aeea2d66de3b2e88898666ee3bff3b6ac73908a7770),
(16, 'Lampoles', '50.000,00', 'disponivel', 'Huíla', 'Chipindo', 'Bambi', 0x0000001c667479706176696600000000617669666d6966316d696166000000ea6d657461000000000000002168646c72000000000000000070696374000000000000000000000000000000000e7069746d00000000000100000022696c6f630000000044400001000100000000010e000100000000000010440000002369696e6600000000000100000015696e6665020000000001000061763031000000006a697072700000004b6970636f00000013636f6c726e636c78000200020006800000000c6176314381010c0000000014697370650000000000000272000001a2000000107069786900000000030808080000001769706d610000000000000001000104818203840000104c6d64617412000a0a1866271d0b0408081a1032b32044500041041050d8029099559722499e3f5843e2d899848a016d6251b14cdb97cd1941c9bd5feb9e3300e00ad0ba579c133265d97fa047fed3a68e8714354317e68f3b5b4137a5c6d0d6964bb449a4adb151f605627471b61a835e01f1e3738e54b951cb269e910747b3123058d94e35e7c4dee07998930f6dcf2026dde0469ab4b1b080a3df4417c8054045be235291b211975fb7103afd065b57fea0b62cee9ab115e012e91c2509fe8aeb56912be3761c28e99ecf7cd04dd6278fade754efb9601d5463aac54807c34cd5f2e59e9dfb83998556ec42be3237bd88caa5c574f33953cff8c8fda6bafb168fbb79885c402565fa9234d941cf65422da58d0494ad73cb80657fe7ed8a63caed3e08d0c55c02a22ae7d00e0afcb6b2150b91b1fd23ce258fd76518bc897d7593bc88d5cade7653d624b134cd3daf9dfbbeb25b16eb8bbba802772a084d4d4734ab1b3a55576f3f2503a0356d8f1bac62ea8c6a1fdd206ee5892c2f87d3771c4dca911f9916433f14bf6e0cad8da139fc6f51b520cfc6c7262b00b6a4d441e1216a6ff5a8969958a06183fa88742a2d752fe6db4c7302b1efa6206537e385b90ce7cbeeeb882d49e77147e624ea4aaccaa2638c787bc7811cb16555eaf46641100aa253ecfa3da41ded79df6535b43d6e075c9ab9e49274c720995e1507b78d437a42b5746e60bcf2ad6d787e0ac87948ef4727fd87e0ffc60e88520fc1a042a3f84b58c278ae3b58e36a6fea72dbb9148247cc0e8d7c34a702180daa6970a479c15b02ca1a282ecc59b818428887777bf62c84692055b6730b83652d65556f8c3f1db13b312e87e960360c645134a2ab544d0a3d70d49ee33997963214cd265109b341d3b9e0e21beb7f13a8541aa60074d6d3cf89ff233f2e0e7f4a4104bca205e0e3492f13061c9bdf0962ea0f23e18fca6b0e07889442ea6d370109674a1fe68253b7c3b171435fa2edac5757cb8e843570101d57ca64a10f8001bcb53c08b7d4eb59710c7d021a405811a17c53f7c78fcbd249fe082828fec01deca0d8444434b4a0a5fc753886fd5a738b6a34369bd77956ba7462c24183fae58546efe3e52df078f247d2dbdaee25c1552de5e1fb19a3e0b22c264e234e0cb70af9246aee12b34404227aff6c4c1ac965144ac56185cd10abb00dce7cc6babf09378dfb3919d1b7d1ced09de0c4cb439e2eb8e2dc0f3e86aaf6fcb41a8005d62e45ad32f2e9d9388e358e5d26006d2a2a0e73521b5eea3dbf1456e07042202612120106f1249d2a3485e06ab350426686dd6a6ca1a45063a962f1489bfafd3695486edc82fa2d354397a1c79a2bb14c8f802bfa3af0276ea83b80c2881368c1f9a02adbc215574b54c40cc6292ec889f8814b1f36a6626f9cfa02e550740f4d8f5e1fa9822f7f586780be322f3f2146907047fa987808ee39620b4f803e4eca3c2a74da1eae8966dd092c2cfebb03ec850c919685d5dfdcc7f8969d40f8aa8560af522d940c765a83cef2350421eb1daf71d3aadbc1b22ddb4ce725960ec0183ef6966e06e62b4e6975e535b5be7d6a3b4f739d3a12bf6d2daffd1205a4c92becdd05b9e3aae6e168447b9b6cf5e70a96dd601793b2f01059c50384fe72d1f2d3c93068cfb34e668ec635265f18d5668d3d1327efa60b9f26adbd4e0f0675ef5e3021558ae9c7e99a936efd8717606a8f2922f3772d8e197fc83d3805f3fe7c3e0f2ebce2cbb6806c8de8b3bd3b492cf4a59f5e904e1a7fbc204e68deaadcce1751d5f9433171062978109f5a0bccf19bc287088a61437c32627e6c25b21a6172cb722fd30302389f8326aabf95daca43d67f3f5826c3574d8d2d71b560b422b63462c08fb2873e0fa293e9fe5ea6f1868de98d2e5373c742795cb2296d86fb083ad13f8ebdc5872b127bbadb6c89e0c9e70bd320fce6533bab4d439c5650c3a239a57fe4ab67cec8667ac53bd4b6eae44becc1c72a148256992699a61f25fcdf09d5ec2cb241998b980aebce5a2679fb8cdeda8802211eb6a8cfbb91f630cc0472a7a0a0381fd7123c6d0a2856200ca7ba89db59769d7190b8a41c6bba822b077015f09f4bb90cfe8e6857938e87c0b84c8ee8c82158753870c8aff75ecef4b71a55b5a71f0da458d6c3e0eea7e87ab895dcab467b99cacaa6836440fb4aa2d102f9b60ef871b9093afe1af5e19d24f3a23ca12e0cbed42138ac7f096e7d707431648c186cb1b0455d79c19b143e19ac642cb8113942f5b4cca3ab64151620ceaac9d5c43eb15e77007903ce3c3f6d3617c6c2cd62cfc758769bb82fe62a277422eba3f4ecd256b40bd34f7476861f92e61ae882f75c766237556e18e943553e79c857c32c338e6b090607802033cb35b788598e9944a1a8d8a110428a8b7c310d66a82a4845beae4c809bed3320a9cfe687ab290693611ba314e3c5a9a9f018dfd2679c77f5e8a6567ff9c7f1158335827026f9377d76a4b7392fe12de5ea9b01d23e0aefc16ed8188f7637f95bd2efa25c6d2df33dc15bb9e9c5ad3d5817b11afa9fc0529015499ee5ab882c2215037f638deb4c72c7cf849ec506dcfe2c009b3c536e24b0d0713f03920ab892ca18a6af7569ab21772981df404c33cb72b747fa4387e8e8801787f09032fff9a50fe3b5f47802ee4728add8a82a982633435ceafebb6d9a30f5b88b8f00838e045eaac408bff64a944e0a930052bd73fb81c724c9e8cd5b3ded24cab6c5427b661ce8d48feae4081b1991f1e718821af9192444d924f5c22c367780a6af9f18b468367bceb05f60866f75d2b639951c4f93978f76448130ab41f23c3ecf9ab5e60185c732ae1d10937218bd20bbc5300bb4790b8c95221f300e9482cf49556e28f37f8eccb8a36072fa2e857b8932fe4ee2314a70917f880a713cba5e33f40787447ca409cfa4664a2ab8e0d2b637ad4de89e97f4ad8113dddb7a1130efbbf2f05855c050af9e62b1aa92c6d3b78de5c4b03d5467f213b1992bd65232f12a7c61838b141cc03fb160fb37e74de384e36311ec8ce79ad611385bc6fc26ff98e839ab409d5330202d85959111f15931dfdc4b669eebb510d4e26bb9fd3bea6474847c25e348cda35a53207ccb55abddc9768b7fe90e821533b0a3b7853f6968a73b33bbcce08cd1dc2109cd4bd02eec4f3b529eaf2817dd37e0f30c91fe41349035cd50505dc852d9aa1aff72294d899ca4c6ecfe54bdcd0e9a666f23f23c08dfad3c6c94791ec42ca6bcfe904dda436c80171591d307ddc5ebe4cd4421b7d8d26d7093c637e4d29989140ecd109ca421baf3188c582440459ae9af82c2f231706c9c351026a97589573e396848c16a37b8278c1bc738c0d37429bba1c2089281e59c4977b9e1026161857b0e2bb8f096b5865a49e4a5b2870e549f9a04d221a54167e4dbb4bfee39e6f71fdb7d9e7857e62a652f769ea1a2c4398ce3e6d179d7ff3a222c57150dbc41839a3c5d6172db6a258fd6a58d445ea7f834ad6ce80c389f38438ea6dc77bd081be10f6c45440b2a9ce62f19bc77991492c8594c92a5585e6fcb82b960971220f882ed7919fb2068afc91f7b2a1e62a92bd81770d65a2ff0716534dbc63936d4d6dfaf93d6e08187de4eb000100ce3d4c29ed801fac741bcc067c2b2df2e05d1b1296c747cbfdd6b75831dfb37e21240cc9895871f6f63b9b1bbdaeead3ccfddc254bf1b0ea5970eb7c12e49ceda182dc6b435653e8c6c77cf3670b3830b2804e1a999101b1354fb33757e5415c0ef256627e2bafe7b0692530f5b02fe60ca55fabb94ce4b6ea30048595c8c76e16103fccd1720067e4832bf48965ca1b409ef28d221e790ff07f2732ceb4647daf7f7519901564fc280415a0d47385171ed6b529e3d36b8eb9722f67878a661de9f80ccab9dfe41fefa2b6c17199dc6bbf71a38e51a38e99d72c9740fc4b16753a5f1a2293df56aa2e436aa909c811e4a25647368167123b399fd387b0f4661a946def2effe954057956d328cc1a0365fdbc1d53870ff0c0a042eb453cf32ce026e4c1f365ea7d481a21723fc68f44faad9527ccf5e3a2a7d865fc119193a1e762092dd4fe27048202430982f72250dfc9d537232eb8ddf0ffec173b3cdb88b316474b15aa7d05da3f04fb9632d4df9c5d393fbcb3d367c9592cd8d07393bea0033af6a6418b8282f572fce0294866bc50b2121e4d9e676cdd669b90e625d41d43b9e424fd56568b49325a99c383c4fc089e11c2ef1157fe8805e97b01f477004acb068fff569902b58dbfa55ca1fc1b10c4b0c843ff6104e3ca0083d01253825d409fcc320bf3865e66d482466965f6b4acbda57c6455b4df131fdd0defd152e04695a93aaf367bad779a868dfacb63510b714898830709cacf81204585bd8e4379d395ecd758dedaba9ae69009f24d8a85a22e63b6f7c67dbc1aacffec801b73cdbcbd914f6eb47c9e262227130285313cb64d9a926fdd1e3c91a0e549e82ba7cba6e948a47917e35aa2d90f4b1a2749a5a313f118f8220fd4a27ed86ee1d9baca20939f7f4059076a41c986f6c11f719f5f3957e865bbf1b8958556c8755f9ded9558b6db83f1add8b900518e26a229c8103f61cfff7d61590f6de36428ad57e272759ca7f71f389ffc0fe0a5547fa9776bf108b0533e9fe14ed0b035506d435545a5d6fefad4b07ea118d94ebc8da090bdf07083d51bf8eaf5b7d669403e30f6d804e04beae4cceab6b92d13c243f6f66e70bb662ec83cc327165d0243e2290b76f48d56123abe1f716eae9f0a6c6dd1aac8a15b5823f03a8535a09fc2530d6de4f149099e44bb970a5b5560519a71f09e3106a100ceec4f594e373bf829c3e2dac4c4b61c6f44843168dc88f372a52aec1c2afc0823ad887c7ae1389ba06786dbafb9688230ce18316b984a2370ea3d321c48874b9403792b86b17ca1f77fdf5cfde303b3f7716dbb94ee2f9ea8962979bad44038bf1bac71ac7696a6da9d3889de513ce3aa23faa940b9d62092422db03307b4325945225f335316f271dbec955fe14574da0857aa0d72a095ba6c0f27fe604a6e4d65ec76f1b2970b52f0e37ffacace1fc53f0faa37a858defd4e0e0d0cb201f08cdf3fd238fd85878820995c780d9753901545438308074e159f1694a31e61429d0cc40c49ef221b2b7453e19d2add91136073e253fffd09df40850a838b5e6619cb363c62e024006021d0638e5682516ff77421108c86e4bbdb6e9712393bf4d24a890f20a9eebb5f6f646774cba3b8ce03fc6e804f3e91b3a339454f30d4b5a67d4a6af6381c2b002bdadb66fe450962132dd4941e4ec63d3a2345ea910a9b015e17315f85c440cbfd677a23f40e821769c6644b0baa87db53e1546f99e909d30c52b1f4200ed8ab8829afe8815a0dcab6c7b83508eb7d44cbc788adf1a51b143a857d00c5ed3b506a1356d725a1767c2e8070bdc0980ce9c4549b5f83fb035ec920f04876c199c651b003695d6056c099eb02e38e909d41f674d69189a48e38696acc81d75e4d0741e48571e1148fc741c091fe2f1ec5e6fca024230a4f9600293ce6fb2be43ae819757fcb7dbdbd476db90d1f0c3306666af6e9456731848a7cce3f6f5bd47c94c56909787e69145d28929f80e19f8b4e750a54d1dda1d1d390a3107bb9a8414d9aa7bb649f91c5febb4705f4172028071e00a59b56ea694b6bc8b782a563c460b1e92484afd39dd6ef13c2cdc09c729334d4515c72436f7bb263f30d64472a188a660a64c7bc58dfd9dbb5fac48cb1b52f0da0c1f8c8bda266493c01a84c7c5634fa2bb962ba84095241df90fa8d5492aeea2d66de3b2e88898666ee3bff3b6ac73908a7770);

-- --------------------------------------------------------

--
-- Estrutura da tabela `provincia`
--

CREATE TABLE `provincia` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `provincia`
--

INSERT INTO `provincia` (`id`, `nome`) VALUES
(1, 'Bengo'),
(2, 'Benguela'),
(3, 'Bié'),
(4, 'Cabinda'),
(5, 'Cuando Cubango'),
(6, 'Cuanza Norte'),
(7, 'Cuanza Sul'),
(8, 'Cunene'),
(9, 'Huambo'),
(10, 'Huíla'),
(11, 'Luanda'),
(12, 'Lunda Norte'),
(13, 'Lunda Sul'),
(14, 'Malanje'),
(15, 'Moxico'),
(16, 'Namibe'),
(17, 'Uíge'),
(18, 'Zaire');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `comuna` varchar(50) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `morada` varchar(50) NOT NULL,
  `contacto` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `estado` varchar(20) DEFAULT 'NEW'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `tipo`, `nome`, `email`, `comuna`, `municipio`, `provincia`, `morada`, `contacto`, `username`, `password`, `estado`) VALUES
(2, 'gestor', 'ruben', 'rubenpedro@gmail.com', 'viana', 'Viana', 'Luanda', 'gamek', '92293939', 'ruben', '123', 'NEW'),
(70, 'gestor', 'teste', '20181497@isptec.co.ao', 'viana', 'viana', 'luanda', 'morro bento', '93939393', 'teste', '1234', 'OLD'),
(77, 'admin', 'elber', '20190444@isptec.co.ao', 'Luanda', 'Luanda', 'Luanda', 'nova vida', '938893750', 'elber', '123', 'NEW'),
(79, 'cliente', 'nitircio', 'nitircio@gmail.com', 'Baía Farta', 'Baía Farta', 'Benguela', 'Baía Farta', '927771129', 'Nitircio', '123', 'NEW');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `alugar_outdoor`
--
ALTER TABLE `alugar_outdoor`
  ADD KEY `outdoor_id` (`outdoor_id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Índices para tabela `analisar_aluguer`
--
ALTER TABLE `analisar_aluguer`
  ADD KEY `outdoor_id` (`outdoor_id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD KEY `user_id` (`user_id`);

--
-- Índices para tabela `comuna`
--
ALTER TABLE `comuna`
  ADD PRIMARY KEY (`id`),
  ADD KEY `municipio_id` (`municipio_id`);

--
-- Índices para tabela `gestor`
--
ALTER TABLE `gestor`
  ADD KEY `gestor_id` (`gestor_id`);

--
-- Índices para tabela `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provincia_id` (`provincia_id`);

--
-- Índices para tabela `nacionalidade`
--
ALTER TABLE `nacionalidade`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `outdoors`
--
ALTER TABLE `outdoors`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comuna`
--
ALTER TABLE `comuna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=532;

--
-- AUTO_INCREMENT de tabela `municipio`
--
ALTER TABLE `municipio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT de tabela `nacionalidade`
--
ALTER TABLE `nacionalidade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;

--
-- AUTO_INCREMENT de tabela `outdoors`
--
ALTER TABLE `outdoors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `provincia`
--
ALTER TABLE `provincia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `alugar_outdoor`
--
ALTER TABLE `alugar_outdoor`
  ADD CONSTRAINT `alugar_outdoor_ibfk_1` FOREIGN KEY (`outdoor_id`) REFERENCES `outdoors` (`id`),
  ADD CONSTRAINT `alugar_outdoor_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `analisar_aluguer`
--
ALTER TABLE `analisar_aluguer`
  ADD CONSTRAINT `analisar_aluguer_ibfk_1` FOREIGN KEY (`outdoor_id`) REFERENCES `outdoors` (`id`),
  ADD CONSTRAINT `analisar_aluguer_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `comuna`
--
ALTER TABLE `comuna`
  ADD CONSTRAINT `comuna_ibfk_1` FOREIGN KEY (`municipio_id`) REFERENCES `municipio` (`id`);

--
-- Limitadores para a tabela `gestor`
--
ALTER TABLE `gestor`
  ADD CONSTRAINT `gestor_ibfk_1` FOREIGN KEY (`gestor_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `municipio`
--
ALTER TABLE `municipio`
  ADD CONSTRAINT `municipio_ibfk_1` FOREIGN KEY (`provincia_id`) REFERENCES `provincia` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
