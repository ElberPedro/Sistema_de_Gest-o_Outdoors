<?php

interface ILocalidadeRepository {
    public function getProvincia();
    public function getNacionalidade();
}
