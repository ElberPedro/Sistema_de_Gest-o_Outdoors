<?php

require_once 'C:/xampp/htdocs/Elber-outdoorXpto/controller/AdminController.php';

$adminController = new AdminController();

$adminController->index();
