<?php
// Importar a classe do PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluir o autoload do PHPMailer
require_once 'PHPMailer-lib/src/Exception.php';
require_once 'PHPMailer-lib/src/PHPMailer.php';
require_once 'PHPMailer-lib/src/SMTP.php';

// Instanciar o objeto do PHPMailer
$mail = new PHPMailer(true);

try {
    // Configurações do servidor SMTP do Gmail
    //Server settings - linha vinda da documentação no github, linha não testada
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = '20190444@isptec.co.ao'; // Insira seu e-mail do Gmail aqui
    $mail->Password = 'Angola@12345'; // Insira sua senha do Gmail aqui
    $mail->SMTPSecure = 'tls';
    //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port = 587;
    
    // Configurações do e-mail
    $mail->setFrom('20190444@isptec.co.ao', 'Outdoor'); // Insira seu e-mail e nome aqui
    $mail->addAddress($emailDestinatario, $nomeDestinatario); // Insira o e-mail e nome do destinatário aqui
    
    $mail->Subject = $assuntoEmail;
    $mail->Subject = '=?UTF-8?B?' . base64_encode($mail->Subject) . '?='; // Define o assunto com a codificação UTF-8

    // Configurações do conteúdo do e-mail
    $mail->isHTML(true); // Define o formato do e-mail como HTML
    $mail->CharSet = 'UTF-8'; // Define a codificação do texto como UTF-8

    // Conteúdo do e-mail em HTML
    $mail->Body = $corpoEmail . '<br><strong>Sistema para Gerir Outdoor!<strong>';
    /*
    $mail->Body = '<h1>Título do E-mail</h1>
                   <p>Este é um exemplo de e-mail em <strong>HTML</strong> com codificação UTF-8.</p>';
    */
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    // Enviar o e-mail
    $mail->send();
    echo '<script>console.log("E-mail enviado com sucesso!");</script>';
} catch (Exception $e) {
    echo 'Erro ao enviar o e-mail: ' . $mail->ErrorInfo;
}
