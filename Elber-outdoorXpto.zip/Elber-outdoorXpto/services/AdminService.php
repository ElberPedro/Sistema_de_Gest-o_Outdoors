<?php

require_once 'C:/xampp/htdocs/Elber-outdoorXpto/services/IAdminService.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/repositories/AdminRepository.php';

class AdminService implements IAdminService {

    private $adminRepository = NULL;

    public function __construct() {
        $this->adminRepository = new AdminRepository();
    }

    public function createUser(User $user) {
        try {

            $existingUser = $this->adminRepository->getUserByEmailOrUsername($user->getEmail(), $user->getUsername());
            if ($existingUser) {
                return false;
            }
             $corpoEmail = "Ativar Conta do Uilizador";
                            $assuntoEmail = "Activar Conta do Utilizador: ".$user->getEmail();
                            $nomeDestinatario = "Administrador";
                            $emailDestinatario = "rubenpedro379@gmail.com"; //Sempre que uma conta for criada irá enviar-te um email
                            require_once '../Libraries/Email.php';
                            echo "Sucesso ao inserir utilizador Registado";
            return $this->adminRepository->registrarUser($user);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
            
            return false;
        }
    }

    public function listAdmin() {
        try {
            return $this->adminRepository->listarAdmin();
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function deletarUser($id) {
        try {
            $this->adminRepository->deleteUser($id);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function loginUser($email, $password) {
        try {
            return $this->adminRepository->login($email, $password);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function insertClient(Cliente $cliente) {
        try {
            return $this->adminRepository->inserirCliente($cliente);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
            return false;
        }
    }

    public function listCliente() {
        try {
            return $this->adminRepository->listarCliente();
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function buscarUserId($id) {
        try {
            return $this->adminRepository->getUserById($id);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function editarUser(User $user) {
        try {
            $this->adminRepository->updateUser($user);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function buscarClienteId($id) {
        try {
            return $this->adminRepository->getClienteById($id);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function updateEstadoCliente($userId, $estado) {
        try {
            return $this->adminRepository->atualizarEstadoCliente($userId, $estado);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function updateAutenticacao($id, $email, $password) {
        try {
            return $this->adminRepository->updateAutenticacao($id, $email, $password);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function updateEmail($Id, $senha) {
        try {
            return $this->adminRepository->updateEmail($Id, $senha);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function buscarEstadoCliente($userId) {
        try {
            return $this->adminRepository->getEstadoCliente($userId);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function deletarCliente($id) {
        try {
            $this->adminRepository->deleteCliente($id);
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

}
