<?php

require_once 'C:/xampp/htdocs/Elber-outdoorXpto/services/ILocalidadeService.php';
require_once 'C:/xampp/htdocs/Elber-outdoorXpto/repositories/LocalidadeRepository.php';

class LocalidadeService implements ILocalidadeService{
    
    private $localidadeRepository = NULL;

    public function __construct() {
        $this->localidadeRepository = new LocalidadeRepository();
    }
    
    public function buscarProvincia() {
        try{
            return $this->localidadeRepository->getProvincia();
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

    public function buscarNacionalidade() {
        try{
            return $this->localidadeRepository->getNacionalidade();
        } catch (Exception $ex) {
            echo "An error occurred while: " . $ex->getMessage();
        }
    }

}
