<?php

interface ILocalidadeService {
    public function buscarProvincia();
    public function buscarNacionalidade();
    
}
